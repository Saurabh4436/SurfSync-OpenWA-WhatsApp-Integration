# Submission Documentation

## Documentation

- [OpenWA Setup](docs/OPENWA_SETUP.md)
- [API Documentation](docs/API_DOCUMENTATION.md)
- [Database Structure](docs/DATABASE_STRUCTURE.md)
- [Technical Explanation](docs/TECHNICAL_EXPLANATION.md)
- [Challenges & Solutions](docs/CHALLENGES.md)
- [Architecture Diagram Source](architecture.mmd)

## Submission assets to add

Create these folders in the repository when ready:

```text
screenshots/
demo/
```

Recommended screenshots:
- application home page
- QR code
- WhatsApp connected/status
- text message sent
- automated webhook reply
- inbox/database message history

# SurfSync Technical Explanation

## 1. Project Overview

SurfSync is a WhatsApp integration application built around Spring Boot, OpenWA, MySQL and webhooks. The project exposes REST endpoints for creating an OpenWA session, checking session status, sending text messages, sending media, retrieving chats, reading locally stored messages, and receiving incoming WhatsApp events through a webhook.

The codebase follows a layered Spring Boot structure. Controllers receive HTTP requests, services contain integration/business logic, and a JDBC repository persists message history in MySQL.

## 2. Technology Stack

- **Backend:** Java / Spring Boot
- **Integration:** OpenWA
- **Database:** MySQL
- **Persistence:** Spring `JdbcTemplate`
- **Validation:** Jakarta Validation
- **Frontend:** HTML, CSS and JavaScript
- **API style:** REST
- **Event handling:** Webhook
- **Build:** Maven

The application is configured to run on port `8080`. OpenWA is configured through a separate base URL, API key and session ID.

## 3. Application Layers

### Controller Layer

The project contains dedicated controllers for health, general WhatsApp APIs, messages, status and webhooks.

Examples include:

- `HealthController`
- `WhatsappApiController`
- `WhatsappMessageController`
- `WhatsappStatusController`
- `WhatsappWebhookController`

This separation keeps HTTP request handling separate from OpenWA integration and database operations.

### DTO Layer

Request classes provide structured API input:

- `CreateSessionRequest`
- `SendMessageRequest`
- `SendMediaRequest`

Required fields use `@NotBlank`, providing basic request validation before service processing.

### Service Layer

`OpenWaService` is responsible for communication with OpenWA. It uses Spring's `RestClient` and sends the configured API key in the `X-API-Key` header.

`WhatsappMessageService` coordinates message persistence and inbox retrieval.

### Repository Layer

`WhatsappMessageRepository` uses `JdbcTemplate` to execute SQL statements against the `whatsapp_messages` table. It stores both incoming and outgoing messages and retrieves recent messages ordered by timestamp.

## 4. OpenWA Integration

The integration uses the configured OpenWA base URL and session ID.

The application supports:

- session creation
- session status
- text messages
- image messages
- video messages
- audio messages
- document messages
- message history

For text messages, a phone number is converted to a WhatsApp chat ID by appending `@c.us`.

For media, the application selects the OpenWA endpoint based on the requested media type.

## 5. Webhook Processing

The webhook is the event-driven part of the application.

OpenWA sends a JSON event to:

```text
POST /api/whatsapp/webhook
```

The controller extracts message-related data such as message ID, sender, chat ID, body, type and whether the message originated from the connected account.

Group and newsletter messages are intentionally ignored by the current implementation.

For an incoming text message, the application:

1. Trims and normalizes the text.
2. Saves the incoming message as `INCOMING`.
3. Checks the text against configured menu commands.
4. Generates an appropriate response.
5. Sends the response through OpenWA.
6. Saves the response as `OUTGOING`.

This provides a simple automated WhatsApp menu/bot workflow without requiring the browser UI to remain involved in every message exchange.

## 6. Automated Menu

The webhook contains a rule-based menu.

Messages such as `hi`, `hello`, `helo`, `menu` and `0` display the main menu.

The current options are:

1. Website Development
2. App Development
3. Internship
4. Contact Sales

Selecting an option generates the corresponding predefined response.

This demonstrates how incoming webhook events can trigger application logic and an outbound WhatsApp response.

## 7. Database Design

The current application persists message history in a MySQL table named `whatsapp_messages`.

The Java code uses these fields:

- `id`
- `message_id`
- `phone_number`
- `direction`
- `message`
- `message_type`
- `status`
- `created_at`

Incoming and outgoing messages share the same table, while `direction` differentiates them.

The repository uses `created_at DESC, id DESC` to return the most recent messages first.

## 8. End-to-End Message Flow

### Outgoing

```text
Client
  ↓
POST /api/whatsapp/send-message
  ↓
Controller
  ↓
OpenWaService
  ↓
OpenWA
  ↓
WhatsApp
```

The outgoing message is also persisted:

```text
WhatsappMessageService
  ↓
WhatsappMessageRepository
  ↓
MySQL
```

### Incoming

```text
WhatsApp
  ↓
OpenWA
  ↓
Webhook
  ↓
WhatsappWebhookController
  ↓
WhatsappMessageService
  ↓
MySQL
```

Then the rule-based response goes back through:

```text
Controller → OpenWaService → OpenWA → WhatsApp
```

## 9. Configuration and Security

The application uses configuration properties for:

- Spring application port
- MySQL URL
- MySQL username/password
- OpenWA base URL
- OpenWA API key
- OpenWA session ID

Secrets should be supplied through environment/configuration mechanisms and must not be committed as real values to a public repository.

## 10. Health Monitoring

The project includes `/api/health`. It executes `SELECT 1` through `JdbcTemplate` and reports the application/database status together with the configured OpenWA address.

This gives a simple readiness/diagnostic endpoint for development and deployment checks.

## 11. Limitations and Future Improvements

The current implementation focuses on the core integration and automation workflow.

Potential future improvements include:

- database migrations such as Flyway/Liquibase
- stronger webhook authentication/signature verification
- structured error responses
- centralized exception handling
- message pagination
- message delivery-status tracking
- persistent session management for multiple WhatsApp accounts
- rate limiting and request authentication
- production logging and monitoring
- automated integration tests
- HTTPS and secure deployment configuration

## 12. Conclusion

SurfSync demonstrates a layered Spring Boot application that connects an HTTP API and web interface to OpenWA, while MySQL provides persistent message history and webhooks enable event-driven automation. The separation between controllers, services and repository code makes the integration easier to understand and extend.

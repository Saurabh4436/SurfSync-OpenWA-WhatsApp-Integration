# OpenWA Setup Documentation

## 1. Architecture prerequisites

SurfSync consists of:

- Spring Boot application
- OpenWA service
- MySQL database
- Browser-based frontend served by the Spring Boot application

The Spring Boot application is configured for port `8080`, while the local OpenWA base URL is configured as `http://localhost:2785`. The MySQL database name is `surfsync_whatsapp`.

## 2. Prerequisites

Install/configure:

1. Java version required by the project's `pom.xml`.
2. MySQL Server.
3. OpenWA service.
4. Git.
5. A WhatsApp account for QR/linked-device authentication.
6. A browser for the SurfSync web interface.

## 3. Clone the repository

```bash
git clone https://github.com/Saurabh4436/SurfSync-OpenWA-WhatsApp-Integration.git
cd SurfSync-OpenWA-WhatsApp-Integration
```

## 4. Create the MySQL database

Create the application database:

```sql
CREATE DATABASE surfsync_whatsapp;
```

The actual `whatsapp_messages` table must exist with the columns used by the repository. If the project has already created it during setup, verify it with:

```sql
USE surfsync_whatsapp;
SHOW CREATE TABLE whatsapp_messages;
```

## 5. Configure application properties

The project expects these configuration values:

```properties
server.port=8080

spring.datasource.url=jdbc:mysql://localhost:3306/surfsync_whatsapp
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD

openwa.base-url=http://localhost:2785
openwa.api-key=YOUR_OPENWA_API_KEY
openwa.session-id=YOUR_OPENWA_SESSION_ID
```

Use `.env.example` as the reference for secret/configuration placeholders where applicable.

**Never commit real passwords, API keys, or session IDs to GitHub.**

## 6. Start OpenWA

Start the OpenWA service according to the OpenWA installation/configuration used by your environment.

Verify that OpenWA is reachable at:

```text
http://localhost:2785
```

The SurfSync `OpenWaService` sends the API key using the `X-API-Key` HTTP header.

## 7. Start Spring Boot

From the project root:

### Windows

```bash
mvnw.cmd spring-boot:run
```

### Linux/macOS

```bash
./mvnw spring-boot:run
```

The application should become available at:

```text
http://localhost:8080
```

## 8. Verify application health

Open:

```text
http://localhost:8080/api/health
```

The endpoint checks the MySQL connection with `SELECT 1` and reports the configured OpenWA URL.

## 9. Create/Open WhatsApp session

Use the application endpoint:

```http
POST /api/whatsapp/session
Content-Type: application/json
```

Example:

```json
{
  "name": "surfsync-session"
}
```

Then use the OpenWA/SurfSync QR flow configured in your running environment to link WhatsApp.

## 10. Verify WhatsApp connection

Call:

```http
GET /api/whatsapp/status
```

The request is forwarded to OpenWA for the configured session.

## 11. Test sending a message

```http
POST /api/whatsapp/send-message
Content-Type: application/json
```

```json
{
  "phone": "919XXXXXXXXX",
  "message": "Hello from SurfSync"
}
```

## 12. Configure webhook

OpenWA should be configured to send incoming message events to:

```text
POST http://<SURFSYNC-HOST>:8080/api/whatsapp/webhook
```

For a local-only test, the OpenWA service must be able to reach the Spring Boot application's local address.

For remote deployment, expose the Spring Boot endpoint through a secure HTTPS URL and configure that URL as the webhook destination.

## 13. Verify automated reply

Send `hi`, `hello`, `menu`, or `0` to the connected WhatsApp account.

The current webhook logic displays a menu containing:

1. Website Development
2. App Development
3. Internship
4. Contact Sales

The bot reply is sent through OpenWA and saved as an outgoing message.

## Troubleshooting

### OpenWA connection fails

- Confirm OpenWA is running.
- Confirm `openwa.base-url`.
- Confirm the API key.
- Confirm the session ID.
- Check the OpenWA logs.

### Database error

- Confirm MySQL is running.
- Confirm database `surfsync_whatsapp` exists.
- Confirm username/password.
- Confirm `whatsapp_messages` exists with the required columns.

### Webhook not received

- Confirm the webhook URL.
- Confirm the Spring Boot application is reachable from OpenWA.
- Check the Spring Boot console logs.
- Test the endpoint with a representative JSON payload.

### Secrets

Do not paste API keys, session IDs, passwords, or QR/session credentials into GitHub issues, README files, screenshots, or public documentation.

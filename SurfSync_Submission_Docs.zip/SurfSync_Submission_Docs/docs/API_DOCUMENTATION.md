# SurfSync API Documentation

## Overview

SurfSync exposes a Spring Boot REST API under `/api/whatsapp`. The application communicates with an OpenWA service and stores WhatsApp message records in MySQL.

**Local Spring Boot base URL:** `http://localhost:8080`

> Replace the base URL with the deployed URL when the application is hosted.

---

## 1. Health Check

### `GET /api/health`

Checks the Spring Boot application and MySQL connection.

### Example response

```json
{
  "application": "UP",
  "database": "UP",
  "openwa": "http://localhost:2785"
}
```

The current implementation performs `SELECT 1` against MySQL before returning the database status.

---

## 2. Create OpenWA Session

### `POST /api/whatsapp/session`

Creates an OpenWA session through the configured OpenWA service.

### Request

```json
{
  "name": "surfsync-session"
}
```

`name` is required.

### Example cURL

```bash
curl -X POST http://localhost:8080/api/whatsapp/session   -H "Content-Type: application/json"   -d '{"name":"surfsync-session"}'
```

---

## 3. Send Text Message

### `POST /api/whatsapp/send-message`

Sends a text message through OpenWA and records the outgoing message in MySQL.

### Request

```json
{
  "phone": "919XXXXXXXXX",
  "message": "Hello from SurfSync"
}
```

Both `phone` and `message` are required.

### Example cURL

```bash
curl -X POST http://localhost:8080/api/whatsapp/send-message   -H "Content-Type: application/json"   -d '{"phone":"919XXXXXXXXX","message":"Hello from SurfSync"}'
```

The service converts the phone number into a WhatsApp chat ID by appending `@c.us`.

---

## 4. Send Media

### `POST /api/whatsapp/send-media`

Sends supported media through OpenWA.

### Required fields

- `phone`
- `mediaType`
- `url`

### Optional fields

- `caption`
- `filename`
- `mimetype`

### Supported media types

- `image`
- `video`
- `audio`
- `document`

### Example: image

```json
{
  "phone": "919XXXXXXXXX",
  "mediaType": "image",
  "url": "https://example.com/image.jpg",
  "caption": "SurfSync image"
}
```

### Example: document

```json
{
  "phone": "919XXXXXXXXX",
  "mediaType": "document",
  "url": "https://example.com/file.pdf",
  "filename": "file.pdf",
  "mimetype": "application/pdf"
}
```

---

## 5. Get WhatsApp Status

### `GET /api/whatsapp/status`

Returns the configured OpenWA session status.

### Example

```bash
curl http://localhost:8080/api/whatsapp/status
```

The Spring Boot service forwards the request to OpenWA using the configured session ID and API key.

---

## 6. Get Chats / Message History from OpenWA

### `GET /api/whatsapp/chats`

Retrieves message history from the configured OpenWA session.

The current service requests up to 100 records with offset 0 from OpenWA.

---

## 7. Get Local Inbox

### `GET /api/whatsapp/inbox?limit=50`

Returns recent messages stored in the local MySQL table.

`limit` defaults to 50 at controller level. The service also protects the value by using 20 for values below 1 and capping values above 100.

### Example

```bash
curl "http://localhost:8080/api/whatsapp/inbox?limit=20"
```

---

## 8. OpenWA Webhook

### `POST /api/whatsapp/webhook`

Receives incoming OpenWA webhook payloads.

The current implementation reads fields such as:

- `data.id`
- `data.from`
- `data.chatId`
- `data.body`
- `data.type`
- `data.fromMe`
- `data.isGroup`

For incoming text messages, the application:

1. Ignores group and newsletter messages.
2. Stores the incoming message in MySQL.
3. Normalizes the text.
4. Generates an automatic reply for configured menu options.
5. Sends the reply through OpenWA.
6. Stores the outgoing bot reply in MySQL.

### Menu behavior

`hi`, `hello`, `helo`, `menu`, and `0` show the main menu.

```text
1. Website Development
2. App Development
3. Internship
4. Contact Sales
```

---

## OpenWA calls used internally

The Spring Boot `OpenWaService` communicates with the OpenWA server using the configured base URL and `X-API-Key` header.

| Purpose | OpenWA endpoint |
|---|---|
| Session status | `GET /api/sessions/{sessionId}` |
| Create session | `POST /api/sessions` |
| Send text | `POST /api/sessions/{sessionId}/messages/send-text` |
| Send image | `POST /api/sessions/{sessionId}/messages/send-image` |
| Send video | `POST /api/sessions/{sessionId}/messages/send-video` |
| Send audio | `POST /api/sessions/{sessionId}/messages/send-audio` |
| Send document | `POST /api/sessions/{sessionId}/messages/send-document` |
| Get messages | `GET /api/sessions/{sessionId}/messages?limit=100&offset=0` |

---

## Validation and error handling

Request DTOs use Jakarta Validation annotations such as `@NotBlank`. OpenWA service calls are wrapped with exception handling and descriptive runtime exceptions for session creation and message/media sending failures.

Do not publish real API keys, database passwords, session IDs, or other secrets.

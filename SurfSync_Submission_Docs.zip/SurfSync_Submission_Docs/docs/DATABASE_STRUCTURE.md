# Database Structure

## Database

The application is configured to use MySQL database:

```text
surfsync_whatsapp
```

The configured JDBC URL is:

```text
jdbc:mysql://localhost:3306/surfsync_whatsapp
```

The repository uses Spring's `JdbcTemplate` rather than a JPA entity/repository model.

## Table: `whatsapp_messages`

The Java repository writes to and reads from a table named `whatsapp_messages`.

### Columns used by the application

| Column | Role | Usage |
|---|---|---|
| `id` | Record identifier | Selected and used for ordering |
| `message_id` | WhatsApp/OpenWA message identifier | Stored for incoming messages |
| `phone_number` | Sender/recipient number or chat ID | Stored for incoming and outgoing messages |
| `direction` | Message direction | `INCOMING` or `OUTGOING` |
| `message` | Message body | Stores text content |
| `message_type` | Message type | Incoming type is supplied by webhook; outgoing text is stored as `TEXT` |
| `status` | Processing/message status | Examples in current code: `RECEIVED`, `SENT` |
| `created_at` | Creation timestamp | Used for recent-message ordering |

### Insert behavior

Incoming messages are inserted with:

```text
message_id
phone_number
direction
message
message_type
status
```

Outgoing messages are inserted with:

```text
phone_number
direction
message
message_type
status
```

`id` and `created_at` are not supplied by the Java INSERT statements, so their exact MySQL definitions/defaults must be taken from the database schema used in the deployment.

## Query used for inbox

Recent records are selected as:

```sql
SELECT
  id,
  message_id,
  phone_number,
  direction,
  message,
  message_type,
  status,
  created_at
FROM whatsapp_messages
ORDER BY created_at DESC, id DESC
LIMIT ?;
```

## Important note

The current GitHub source does **not contain a SQL migration/schema file**, so this document intentionally does not invent exact MySQL data types, primary-key definitions, indexes, or default expressions. Add the actual `SHOW CREATE TABLE whatsapp_messages;` output here if you have the database schema.

## Logical relationship

The current application has one explicitly used persistent table:

```text
whatsapp_messages
```

It is accessed by:

```text
WhatsappWebhookController
        ↓
WhatsappMessageService
        ↓
WhatsappMessageRepository
        ↓
JdbcTemplate
        ↓
MySQL: whatsapp_messages
```

# Challenges Faced and Solutions

## 1. Connecting Spring Boot with OpenWA

### Challenge
The application needed to communicate with a separately running OpenWA service rather than handling the WhatsApp integration directly inside Spring Boot.

### Solution
A dedicated `OpenWaService` was created. It centralizes OpenWA HTTP calls, reads the base URL/API key/session ID from configuration, and uses Spring `RestClient` for requests.

---

## 2. Session and Authentication Configuration

### Challenge
The OpenWA integration requires session-specific configuration and API authentication.

### Solution
The project externalizes the OpenWA base URL, API key and session ID into application configuration instead of hard-coding them into controller logic. Real secrets should remain outside the public repository.

---

## 3. Converting Phone Numbers to WhatsApp Chat IDs

### Challenge
The application API accepts a phone number, while OpenWA text/media operations use a WhatsApp chat ID.

### Solution
The service/controller layer converts a phone number into the expected chat ID format by appending `@c.us` before sending the request.

---

## 4. Handling Multiple Media Types

### Challenge
Image, video, audio and document messages use different OpenWA endpoints and payload fields.

### Solution
`OpenWaService.sendMedia()` selects the endpoint based on `mediaType` and builds the appropriate request body. Unsupported media types are rejected with an `IllegalArgumentException`.

---

## 5. Receiving Incoming Messages

### Challenge
Outgoing API calls are request/response operations, but incoming WhatsApp messages arrive asynchronously.

### Solution
A webhook endpoint was added at `/api/whatsapp/webhook`. It parses the incoming OpenWA event, extracts the relevant message data, stores the message and then triggers the configured reply logic.

---

## 6. Avoiding Unwanted Group/Newsletter Automation

### Challenge
The bot should not automatically process every incoming text event.

### Solution
The webhook checks group/newsletter indicators and ignores those messages before running the automated menu logic.

---

## 7. Message Persistence

### Challenge
The system needed a local history of incoming and outgoing messages.

### Solution
`WhatsappMessageService` and `WhatsappMessageRepository` were added. `JdbcTemplate` performs inserts and recent-message queries against the `whatsapp_messages` table.

---

## 8. Input Validation

### Challenge
Missing phone numbers, messages, session names or media information could cause invalid integration requests.

### Solution
Request DTOs use Jakarta `@NotBlank` validation for required fields.

---

## 9. Debugging Integration Issues

### Challenge
An integration involving Spring Boot, OpenWA, WhatsApp and MySQL has multiple points where a failure can occur.

### Solution
The project includes a health endpoint and logs webhook payloads/processing information. This makes it easier to identify whether the issue is in the application, database or OpenWA connection.

---

## 10. GitHub Security

### Challenge
Configuration contains sensitive values such as database passwords, OpenWA API keys and session identifiers.

### Solution
The repository uses placeholder configuration values and an `.env.example` file. Real credentials should be kept in local environment/configuration and excluded from Git.
